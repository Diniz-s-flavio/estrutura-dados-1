/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class ListaEncadeadaDupla {
    private Nodo2 head;
    private Nodo2 tail;

    public Nodo2 getHead() {
        return head;
    }

    public void setHead(Nodo2 head) {
        this.head = head;
    }

    public Nodo2 getTail() {
        return tail;
    }

    public void setTail(Nodo2 tail) {
        this.tail = tail;
    }

    public ListaEncadeadaDupla() {
        this.head = null;
        this.tail = this.head;
    }

    public void addFirst(int item) {
        Nodo2 newNode = new Nodo2(item);
        newNode.setNext(this.head);

        if (!this.isEmpty()) {
            this.head.setPrevious(newNode);
        } else {
            this.tail = newNode;
        }

        this.head = newNode;
    }

    public void addLast(int item) {
        Nodo2 newNode = new Nodo2(item);
        newNode.setPrevious(this.tail);
        if (this.isEmpty()) {
            this.head = newNode;
        }else {
            this.tail.setNext(newNode);
        }
        this.tail = newNode;

    }

    public void addOrdered(int item) {
        Nodo2 newNode = new Nodo2(item);
        if (!newNode.hasNext()) {
            head = newNode;
            tail = newNode;
        } else {
            Nodo2 current = head;
            while (current != null && (Integer) current.getItem() < (Integer) item) {
                current = current.getNext();
            }
            newNode.setNext(current);
            if (current == null) {
                newNode.setNext(null);
                newNode.setPrevious(tail);
                tail.setNext(newNode);
                tail = newNode;
            }else if (current.equals(head)) {
                head = newNode;
                newNode.setPrevious(null);
                newNode.setNext(current);
                current.setPrevious(newNode);
            }else {
                Nodo2 previous = current.getPrevious() ;
                newNode.setPrevious(previous);
                newNode.setNext(current);
                previous.setNext(newNode);
                current.setPrevious(newNode);
            }
        }


    }

    public Object removeFirst() {
        this.throwExceptionIfEmpty();

        Object returnedItem = head.getItem();
        Nodo2 current = this.head.getNext();

        if (current == null) {
            head = null;
            tail = head;
        } else {
            current.setPrevious(null);
            head = current;
        }

        return returnedItem;
    }

    public Object removeLast() {
        this.throwExceptionIfEmpty();

        Object returnedItem = this.tail.getItem();

        Nodo2 current = this.head;

        if (current == null) {
            head = null;
            tail = head;
        } else {
            current.setNext(null);
            tail = current;
        }

        return returnedItem;
    }


    public Object remove(Object key) {
        Object item;
        this.throwExceptionIfEmpty();

        Nodo2 current = this.head;

        while (current.hasNext() && !current.getItem().equals(key)) {
            current = current.getNext();
        }

        if (current == null) {
            return null;
        } else {
            item = current.getItem();

            if (!current.hasPrevious()) {
                Nodo2 newHead = head.getNext();

                if(newHead == null) {
                    head = null;
                    tail = head;
                } else {
                    newHead.setPrevious(null);
                    head = newHead;
                }
                this.tail = current;
            }
        }

        Nodo2 q = current.getNext();
        Object returnedItem = q.getItem();
        current.setNext(q.getNext());



        return returnedItem;
    }

    public Object pesquisa (Object chave) {
        this.throwExceptionIfEmpty();
        Nodo2 current = head;
        while (current.getNext() != null ) {
            if (current.getNext().getItem().equals(chave))
                return current.getNext().getItem();
            current = current.getNext();
        }
        return null;
    }

    public void print() {
        if (this.isEmpty()){
            System.out.println("A lista está vazia.");
            return;
        }
        Nodo2 current = this.head;
        while (current != null) {
            System.out.print(current + (current.hasNext() ? ", ": ""));
            current = current.getNext();
        }
    }

    public boolean isEmpty() {
        return this.head == null;
    }

    public void throwExceptionIfEmpty() {
        if (this.isEmpty()) {
            throw new IllegalStateException("A lista está vazia.");
        }
    }

    public void removerTodos(int valor) {
        Nodo2 current = this.head;

        while (current != null) {
            Nodo2 proximo = current.getNext();

            if (current.getItem().equals(valor)) {
                if (current.hasPrevious()) {
                    current.getPrevious().setNext(proximo);
                } else {
                    this.head = proximo;
                }

                if (proximo != null) {
                    proximo.setPrevious(current.getPrevious());
                } else {
                    this.tail = current.getPrevious();
                }
            }

            current = proximo;
        }
    }
}
