/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class ListaCircularDupla {
    private Nodo2 head;

    public ListaCircularDupla() {
        this.head = null;
    }


    public boolean isEmpty() {
        return this.head == null;
    }

    public void throwExceptionIfEmpty() {
        if (isEmpty()) throw new IllegalStateException("A lista está vazia.");
    }

    public Nodo2 getHead() {
        return head;
    }

    public void setHead(Nodo2 head) {
        this.head = head;
    }

    public void addFirst(int item) {
        Nodo2 newNode = new Nodo2(item);
        if (isEmpty()) {
            newNode.setNext(newNode);
            newNode.setPrevious(newNode);
            head = newNode;
        } else {
            Nodo2 tail = head.getPrevious();
            newNode.setNext(head);
            newNode.setPrevious(tail);
            tail.setNext(newNode);
            head.setPrevious(newNode);
            head = newNode;
        }
    }

    public void addLast(int item) {
        Nodo2 newNode = new Nodo2(item);
        if (isEmpty()) {
            newNode.setNext(newNode);
            newNode.setPrevious(newNode);
            head = newNode;
        } else {
            Nodo2 tail = head.getPrevious();
            newNode.setNext(head);
            newNode.setPrevious(tail);
            tail.setNext(newNode);
            head.setPrevious(newNode);
        }
    }

    public void addOrdered(int item) {
        if (isEmpty()) {
            addLast(item);
            return;
        }

        if (item <= head.getItem()) {
            addFirst(item);
            return;
        }

        Nodo2 current = head.getNext();

        while (current != head && current.getItem() < item) {
            current = current.getNext();
        }

        Nodo2 newNode = new Nodo2(item);
        Nodo2 prev = current.getPrevious();

        newNode.setNext(current);
        newNode.setPrevious(prev);
        prev.setNext(newNode);
        current.setPrevious(newNode);
    }

    public int removeFirst() {
        throwExceptionIfEmpty();
        int value = head.getItem();

        if (head.getNext() == head) {
            head = null;
        } else {
            Nodo2 tail = head.getPrevious();
            Nodo2 newHead = head.getNext();
            tail.setNext(newHead);
            newHead.setPrevious(tail);
            head = newHead;
        }
        return value;
    }

    public int removeLast() {
        throwExceptionIfEmpty();
        Nodo2 tail = head.getPrevious();
        int value = tail.getItem();

        if (tail == head) {
            head = null;
        } else {
            Nodo2 newTail = tail.getPrevious();
            newTail.setNext(head);
            head.setPrevious(newTail);
        }
        return value;
    }

    public Integer remove(int key) {
        throwExceptionIfEmpty();

        Nodo2 current = head;
        do {
            if (current.getItem() == key) {
                if (current.getNext() == current) {
                    head = null;
                } else {
                    current.getPrevious().setNext(current.getNext());
                    current.getNext().setPrevious(current.getPrevious());
                    if (current == head) {
                        head = current.getNext();
                    }
                }
                return current.getItem();
            }
            current = current.getNext();
        } while (current != head);

        return null;
    }

    public void removerTodos(int valor) {
        if (isEmpty()) return;

        Nodo2 current = head;
        do {
            Nodo2 proximo = current.getNext();

            if (current.getItem() == valor) {
                if (current.getNext() == current) {
                    head = null;
                    return;
                }
                current.getPrevious().setNext(current.getNext());
                current.getNext().setPrevious(current.getPrevious());
                if (current == head) {
                    head = current.getNext();
                }
            }

            current = proximo;
        } while (current != head);
    }

    public Integer pesquisa(int chave) {
        throwExceptionIfEmpty();
        Nodo2 current = head;
        do {
            if (current.getItem() == chave) return current.getItem();
            current = current.getNext();
        } while (current != head);
        return null;
    }

    public Nodo2 findNodeByKey(int key) {
        throwExceptionIfEmpty();
        Nodo2 current = head;
        do {
            if (current.getItem() == key) return current;
            current = current.getNext();
        } while (current != head);
        return null;
    }

    // 7) Escreva um método que receba uma lista duplamente encadeada circular e retorne a
    //quantidade de elementos da lista.
    public int tamanho() {
        if (isEmpty()) return 0;
        int count = 1;
        Nodo2 current = head.getNext();
        while (current != head) {
            count++;
            current = current.getNext();
        }
        return count;
    }

    public void print() {
        if (isEmpty()) {
            System.out.println("A lista está vazia.");
            return;
        }
        Nodo2 current = head;
        do {
            System.out.print(current.getItem());
            current = current.getNext();
            if (current != head) System.out.print(", ");
        } while (current != head);
        System.out.println();
    }
}
