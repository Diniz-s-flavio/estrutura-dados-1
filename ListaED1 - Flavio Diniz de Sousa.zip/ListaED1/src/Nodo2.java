/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class Nodo2 {
    private Integer item;
    private Nodo2 next;
    private Nodo2 previous;

    public Nodo2(int item) {
        this.item = item;
        this.next = null;
        this.previous = null;
    }

    public Integer getItem() {
        return item;
    }

    public void setItem(int item) {
        this.item = item;
    }

    public Nodo2 getNext() {
        return next;
    }

    public void setNext(Nodo2 next) {
        this.next = next;
    }

    public Nodo2 getPrevious() {
        return previous;
    }

    public void setPrevious(Nodo2 previous) {
        this.previous = previous;
    }

    @Override
    public String toString() {
        return this.item.toString();
    }

    public boolean hasNext() {
        return this.next != null;
    }
    public boolean hasPrevious() {
        return this.previous != null;
    }
}
