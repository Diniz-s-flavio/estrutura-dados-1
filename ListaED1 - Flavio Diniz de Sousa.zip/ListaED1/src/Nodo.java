/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class Nodo {
    private Integer item;
    private Nodo next;

    public Nodo(Integer item) {
        this.item = item;
        this.next = null;
    }

    public Nodo() {
        this.item = null;
        this.next = null;
    }

    public Integer getItem() {
        return item;
    }

    public void setItem(Integer item) {
        this.item = item;
    }

    public Nodo getProx() {
        return next;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }

    @Override
    public String toString() {
        return this.item.toString();
    }

    public boolean temProx() {
        return this.next != null;
    }
}
