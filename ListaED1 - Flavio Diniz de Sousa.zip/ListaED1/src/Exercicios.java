/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class Exercicios {

    // 1) Implementar um método para procurar uma substring em uma lista estática de
    //caracteres. O método deve conter a seguinte assinatura: strsbstr(l1, i1, i2)., onde l1 é a lista estática
    //de caracteres, i1 é o início da substring e i2 é o fim da substring. Esse método retorna uma lista com
    //a substring desejada. A lista 11 permanece inalterada.
    public static ListaEstatica strsbstr(ListaEstatica li, int i1, int i2) throws Exception {
        if (li.isVasia()) {
            throw new Exception("Lista esta vasia Vasia");
        }

        if (i1 < 0 || i2 > li.getUltimo()) {
            throw new Exception("Os indices estão fora do alcance da lista");
        }

        if (i1 > i2) {
            throw new Exception("O primeiro Indice deve ser maior que o segundo");
        }


        ListaEstatica listaRetorno = new ListaEstatica(li.getItens().length);

        for (int i = i1; i<= i2;i++){
            listaRetorno.insereUltimo(li.buscaPorIndice(i));
        }

        return listaRetorno;
    }

    public static void testeE1() throws Exception {
        ListaEstatica li = new ListaEstatica(5);
        li.insere(1);
        li.insere(2);
        li.insere(3);
        li.insere(4);
        li.insere(5);


        System.out.println("Lista:");
        li.print();

        System.out.println("Sublista:");
        strsbstr(li, 0, 2).print();
    }

    //    2) Faça um método para intercalar listas encandeadas ordenadamente: o método recebe
    //duas listas encandeadas ordenadas crescente e retorna uma lista encandeada com os elementos das
    //duas listas intercalados, porém obedecendo a ordem crescente dos números.
    public static ListaEncadeada intercala(ListaEncadeada l1, ListaEncadeada l2) {
        ListaEncadeada resultado = new ListaEncadeada();

        Nodo aux1 = l1.getHead().getProx();
        Nodo aux2 = l2.getHead().getProx();

        while (aux1 != null && aux2 != null) {
            if (aux1.getItem() <= aux2.getItem()) {
                resultado.insereUltimo(aux1.getItem());
                aux1 = aux1.getProx();
            } else {
                resultado.insereUltimo(aux2.getItem());
                aux2 = aux2.getProx();
            }
        }

        while (aux1 != null) {
            resultado.insereUltimo(aux1.getItem());
            aux1 = aux1.getProx();
        }

        while (aux2 != null) {
            resultado.insereUltimo(aux2.getItem());
            aux2 = aux2.getProx();
        }

        return resultado;
    }

    public static void testeE2() {
        ListaEncadeada l1 = new ListaEncadeada();
        l1.insereUltimo(1);
        l1.insereUltimo(3);
        l1.insereUltimo(5);
        l1.insereUltimo(7);
        l1.insereUltimo(9);

        ListaEncadeada l2 = new ListaEncadeada();
        l2.insereUltimo(2);
        l2.insereUltimo(4);
        l2.insereUltimo(10);

        System.out.println("Lista 1:");
        l1.print();

        System.out.println("\nLista 2:");
        l2.print();

        System.out.println("\nLista intercalada:");
        intercala(l1, l2).print();
    }

    //    3) Escreva um método dividirAoMeio() que divida a lista original em duas novas listas de
    //tamanhos iguais (se o tamanho for ímpar, a primeira lista pode ter um nó a mais). No final, deve
    //imprimir as duas novas listas. Observação: antes de iniciar o processo de divisão deve-se imprimir a
    //lista original.
    public static void dividirAoMeio(ListaEncadeada li) throws Exception {
        if (li.isVasio()) {
            throw new Exception("Lista vazia, não há o que dividir.");
        }

        System.out.println("Lista inicial:");
        li.print();

        ListaEncadeada l1 = new ListaEncadeada();
        ListaEncadeada l2 = new ListaEncadeada();

        Nodo aux = li.getHead().getProx();

        int comprimentoLi = 0;
        Nodo contador = li.getHead().getProx();
        while (contador != null) {
            comprimentoLi++;
            contador = contador.getProx();
        }

        int comprimentoL1 = comprimentoLi / 2;
        if (comprimentoLi % 2 == 1) {
            comprimentoL1 += 1;
        }

        for (int i = 0; i < comprimentoL1; i++) {
            l1.insereUltimo(aux.getItem());
            aux = aux.getProx();
        }

        while (aux != null) {
            l2.insereUltimo(aux.getItem());
            aux = aux.getProx();
        }

        System.out.println("\nLista 1:");
        l1.print();

        System.out.println("\nLista 2:");
        l2.print();
    }

    public static void testeE3() throws Exception {
        ListaEncadeada li = new ListaEncadeada();
        li.insere(1);
        li.insere(3);
        li.insere(5);
        li.insere(7);
        li.insere(9);
        li.insere(2);
        li.insere(4);

        dividirAoMeio(li);
    }


    //4) Implemente o jogo de Josephus: N pessoas estão em um círculo. Começando pela
    //primeira pessoa, você pula M pessoas e elimina a próxima, repetindo o processo até que reste
    //apenas uma. Escreva um método josephus(int n, int m) que cria uma lista circular de N nós
    //(numerados de 1 a N) e retorna o número do nó sobrevivente. Fazer com que o método imprima a
    //ordem em que as pessoas são eliminadas antes de retornar o vencedor.
    public static int josephus(int n, int m) {
        ListaCircular circle = new ListaCircular();

        for (int i = 1; i <= n; i++) {
            circle.insere(i);
        }

        Nodo atual = circle.getLista();

        System.out.println("Ordem de eliminação:");

        while (atual.getProx() != atual) {
            for (int i = 1; i < m; i++) {
                atual = atual.getProx();
            }
            int eliminado = circle.removeProximo(atual);
            System.out.println("Eliminado: " + eliminado);
        }

        int vencedor = atual.getItem();
        System.out.println("Vencedor: " + vencedor);
        return vencedor;
    }

    public static void testeE4(){
        josephus(10, 3);
    }


    // 5) Crie um método removerTodos(int valor) que percorra a lista e remova todos os nós
    //que contenham o valor especificado.
    public static void testeE5() {
        ListaEncadeadaDupla li = new ListaEncadeadaDupla();
        li.addLast(1);
        li.addLast(3);
        li.addLast(3);
        li.addLast(5);
        li.addLast(3);
        li.addLast(7);

        System.out.println("Lista original:");
        li.print();

        li.removerTodos(3);

        System.out.println("\nApós removerTodos(3):");
        li.print();
    }

    // 6) Implementar um método para procurar uma substring em uma lista duplamente
    //encadeada de caracteres. O método deve conter a seguinte assinatura: strsbstr(l1, i1, i2)., onde l1 é a
    //lista duplamente encadeada de caracteres, i1 é o início da substring e i2 é o fim da substring. Esse
    //método retorna uma lista com a substring desejada. A lista 11 permanece inalterada.
    public static ListaEncadeadaDupla strsubstr(ListaEncadeadaDupla l1, int i1, int i2) {
        if (i1 < 0 || i2 < i1) {
            throw new IllegalArgumentException("Índices inválidos.");
        }

        ListaEncadeadaDupla resultado = new ListaEncadeadaDupla();

        Nodo2 current = l1.getHead();
        int indice = 0;

        // Avança até i1
        while (current != null && indice < i1) {
            current = current.getNext();
            indice++;
        }

        // Copia de i1 até i2
        while (current != null && indice <= i2) {
            resultado.addLast(current.getItem());
            current = current.getNext();
            indice++;
        }

        return resultado;
    }

    public static void testeE6() {
        ListaEncadeadaDupla li = new ListaEncadeadaDupla();
        li.addLast(1);
        li.addLast(2);
        li.addLast(3);
        li.addLast(4);
        li.addLast(5);

        System.out.println("Lista original:");
        li.print();

        System.out.println("\nSubstring dos index [1, 3]:");
        strsubstr(li, 1, 3).print();

        System.out.println("\nLista original após strsubstr (inalterada):");
        li.print();
    }

    public static void testeE7() {
        ListaCircularDupla li = new ListaCircularDupla();
        li.addLast(1);
        li.addLast(2);
        li.addLast(3);
        li.addLast(4);
        li.addLast(5);

        System.out.println("Lista:");
        li.print();
        System.out.println("Tamanho: " + li.tamanho());
    }
}
