/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class ListaEstatica {
    private Integer[] itens;

    private int primeiro;

    private int ultimo;

    public ListaEstatica(int maxTam) {
        itens = new Integer[maxTam];
        primeiro = 0;
        ultimo = 0;
    }

    public boolean isVasia() {
        return primeiro == ultimo;
    }

    public boolean isCheia() {
        return ultimo == itens.length;
    }

    public void inserePrimeiro(int element) {
        if (isCheia()) {
            throw new RuntimeException("A lista ta cheia não vai ter como!");
        }
        for (int i = primeiro; i <= ultimo; i--) {
            if ((Integer) itens[i] > (Integer)element) itens[i + 1] = itens[i];
        }
        itens[ultimo] = element;
        ultimo++;
    }

    public void insereUltimo(int element) {
        if (isCheia()) {
            throw new RuntimeException("A lista ta cheia não vai ter como!");
        }
        itens[ultimo] = element;
        ultimo++;
    }

    public void insere(int element) {
        if (isCheia()) {
            throw new RuntimeException("A lista ta cheia não vai ter como!");
        }
        for (int i = primeiro - 1; i >= ultimo; i--) {
            itens[i + 1] = itens[i];
        }
        itens[ultimo] = element;
        ultimo++;
    }

    public Object removePrimeiro(){
        if (isVasia()){
            throw new RuntimeException("lista vazia não há nada a ser removido!");
        }

        Object items = this.itens[0];
        this.ultimo--;

        for (int i = 0; i < this.ultimo; i++) {
            this.itens[i] = this.itens[i + 1];
        }

        return items;
    }

    public Object removeUltimo(){
        if (isVasia()){
            throw new RuntimeException("lista vazia não há nada a ser removido!");
        }

        Object items = this.itens[this.ultimo - 1];
        this.ultimo--;

        return items;
    }

    public Object remove (Object key) throws Exception {
        if (isVasia() || key == null) {
            throw new RuntimeException("lista vazia não há nada a ser removido!");
        }
        int p = 0;
        while(p < ultimo && !itens[p].equals(key)) {
            p++;
        }
        if (p == ultimo) {
            return null;
        }
        Object item = this.itens[p];
        this.ultimo--;

        for (int i = p; i < this.ultimo; i++) {
            this.itens[i] = this.itens[i + 1];
        }

        return item;
    }

    public Integer busca(Object key) {
        if (isVasia() || key == null) {
            throw new RuntimeException("lista vazia não há nada a ser encontrado!");
        }
        for (int p = 0; p < ultimo; p++) {
            if (itens[p].equals(key)) {
                return itens[p];
            }
        }
        return null;
    }

    public void print(){
        for (int i = primeiro; i < ultimo; i++){
            System.out.print(itens[i] + (i != ultimo - 1?", ":""));
        }
        System.out.print("\n");
    }

    public Integer buscaPorIndice(int i) {
        if (isVasia() || i < 0 || i > this.itens.length) {
            throw new RuntimeException("lista vazia, ou indice não pode ser encontrado!");
        }
        return itens[i];
    }

    public Integer[] getItens() {
        return itens;
    }

    public void setItens(Integer[] itens) {
        this.itens = itens;
    }

    public int getPrimeiro() {
        return primeiro;
    }

    public void setPrimeiro(int primeiro) {
        this.primeiro = primeiro;
    }

    public int getUltimo() {
        return ultimo;
    }

    public void setUltimo(int ultimo) {
        this.ultimo = ultimo;
    }
}
