/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class ListaEncadeada {
    private Nodo head;
    private Nodo tail;

    public ListaEncadeada() {
        this.head = new Nodo();
        this.tail = this.head;
    }

    public void inserePrimeiro(Integer item) {
        Nodo newNode = new Nodo(item);

        this.head.setNext(newNode);
        if (isVasio()) {
            this.tail = newNode;
        } else {
            newNode.setNext(this.head);
            this.head = newNode;
        }
    }

    public void insereUltimo(Integer item) {
        Nodo newNode = new Nodo(item);
        if (this.isVasio()) {
            this.head.setNext(newNode);
            this.tail = newNode;
            return;
        }
        tail.setNext(newNode);
        tail = newNode;
    }

    public void insere(Integer item) {
        Nodo newNode = new Nodo(item);
        Nodo current = this.head;

        while (current.temProx() && current.getProx().getItem() < item) {
            current = current.getProx();
        }

        newNode.setNext(current.getProx());
        current.setNext(newNode);

        if (newNode.getProx() == null) {
            this.tail = newNode;
        }
    }

    public Integer removePrimeiro() {
        this.lancaExceptionSeVasio();

        Nodo current = this.head;

        Nodo previous = this.head.getProx();

        Integer returnedItem = previous.getItem();

        current.setNext(previous.getProx());

        if (!current.temProx()) {
            this.tail = current;
        }

        return returnedItem;
    }

    public Integer removeUltimo() {
        this.lancaExceptionSeVasio();

        Integer returnedItem = this.tail.getItem();
        Nodo current = this.head;

        while (current.temProx() && current.getProx() != this.tail ) {
            current = current.getProx();
        }

        current.setNext(null);
        this.tail = current;

        return returnedItem;
    }


    public Integer remove(Object item) {
        this.lancaExceptionSeVasio();

        Nodo current = this.head;

        while (current.temProx() && !current.getProx().getItem().equals(item)) {
            current = current.getProx();
        }

        if (!current.temProx()) {
            return null;
        }

        Nodo q = current.getProx();
        Integer returnedItem = q.getItem();
        current.setNext(q.getProx());

        if (!current.temProx()) {
            this.tail = current;
        }

        return returnedItem;
    }

    public Object pesquisa (Object chave) {
        this.lancaExceptionSeVasio();
        Nodo current = head;
        while (current.getProx() != null ) {
            if (current.getProx().getItem().equals(chave))
                return current.getProx().getItem();
            current = current.getProx();
        }
        return null;
    }

    public Nodo findNodeByKey (Object key) {
        this.lancaExceptionSeVasio();
        Nodo current = head;
        while (current.temProx() ) {
            if (current.getProx().getItem().equals(key))
                return current.getProx();

            current = current.getProx();
        }
        return null;
    }

    public void print() {
        if (this.isVasio()){
            System.out.println("A lista está vazia.");
            return;
        }
        Nodo current = this.head.getProx();
        while (current != null) {
            System.out.print(current +(current.temProx() ? ", ": ""));
            current = current.getProx();
        }
    }

    public boolean isVasio() {
        return this.head == this.tail;
    }

    public void lancaExceptionSeVasio() {
        if (this.isVasio()) {
            throw new IllegalStateException("A lista está vazia.");
        }
    }


    public Nodo getHead() {
        return head;
    }

    public void setHead(Nodo head) {
        this.head = head;
    }

    public Nodo getTail() {
        return tail;
    }

    public void setTail(Nodo tail) {
        this.tail = tail;
    }
}
