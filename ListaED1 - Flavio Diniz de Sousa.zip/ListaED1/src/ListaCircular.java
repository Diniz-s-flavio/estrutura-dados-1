/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class ListaCircular {
    private Nodo lista;

    public ListaCircular() {
        this.lista = null;
    }

    public boolean isVazio() {
        return this.lista == null;
    }

    public void insere(Integer item) {
        Nodo novo = new Nodo(item);
        if (isVazio()) {
            novo.setNext(novo);
            this.lista = novo;
        } else {
            novo.setNext(this.lista.getProx());
            this.lista.setNext(novo);
            this.lista = novo;
        }
    }

    public Integer removeProximo(Nodo anterior) {
        if (isVazio()) throw new IllegalStateException("Lista vazia.");

        Nodo aRemover = anterior.getProx();
        Integer valor = aRemover.getItem();

        if (aRemover == anterior) {
            this.lista = null;
        } else {
            anterior.setNext(aRemover.getProx());
            if (aRemover == this.lista) {
                this.lista = anterior;
            }
        }
        return valor;
    }

    public Nodo getLista() {
        return lista;
    }
}
