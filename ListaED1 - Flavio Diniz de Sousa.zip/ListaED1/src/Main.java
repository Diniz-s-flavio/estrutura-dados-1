/**
 * Aluno: Flávio Diniz de Sousa
 * Disciplina: Estrutura de Dados 1
 * Data: 25/03/2026
 * */
public class Main {
    public static void main(String[] args) throws Exception {

//        Exercicios.testeE1();

//        Exercicios.testeE2();

//        Exercicios.testeE3();

//        Exercicios.testeE4();

//        Exercicios.testeE5();

        Exercicios.testeE6();

//        Exercicios.testeE7();


    }
}